export interface IVideoBlockProps {
    desktopVideoSrc: string;
    mobileVideoSrc: string;
}

export interface IVideo {
    videoSrc: string;
}