export const API_URL = import.meta.env.VITE_API_URL;

export const GOOGLE_CLIENT_ID = import.meta.env.VITE_API_GOOGLE_CLIENT_ID;