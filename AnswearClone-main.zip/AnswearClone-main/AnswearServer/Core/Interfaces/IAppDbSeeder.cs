﻿namespace Core.Interfaces;

public interface IAppDbSeeder
{
    Task SeedAsync();
}
