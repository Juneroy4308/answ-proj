﻿namespace Core.ViewModels.TargetGroup;
public class TargetGroupUpdateVm
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}
