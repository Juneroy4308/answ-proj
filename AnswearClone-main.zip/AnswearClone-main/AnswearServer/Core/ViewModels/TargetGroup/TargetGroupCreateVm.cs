﻿namespace Core.ViewModels.TargetGroup;

public class TargetGroupCreateVm
{
    public string Name { get; set; } = null!;

}
