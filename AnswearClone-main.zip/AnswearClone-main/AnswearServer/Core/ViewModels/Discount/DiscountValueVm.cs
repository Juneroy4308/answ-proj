﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.ViewModels.Discount
{
    public class DiscountValueVm
    {
        public int Id { get; set; }
        public decimal Percentage { get; set; }
    }
}
