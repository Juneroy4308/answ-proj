﻿namespace Core.ViewModels.Pagination;

public class PaginationVm
{
    public int? PageIndex { get; set; }
    public int? PageSize { get; set; }
}

